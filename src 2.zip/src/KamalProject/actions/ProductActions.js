import Dispatcher from '../dispatcher/Dispatcher';
import ProductApi from '../data/ProductApi';
import * as ActionTypes from '../constants/ActionTypes';

export default class ProductActions {
    static addProduct(product) {
        let newProduct = ProductApi.saveProduct(product);
        //console.log("Dispatching Add Comment ...");
        Dispatcher.dispatch({
            actionType: ActionTypes.ADD_PRODUCT, // type
            product: newProduct  // payload
        });
    }
    static addProductToCart(product) {
        let newProduct = ProductApi.saveProductToCart(product);
        //console.log("Dispatching Add Comment ...");
        Dispatcher.dispatch({
            actionType: ActionTypes.ADD_PRODUCT_Cart, // type
            product: newProduct  // payload
        });
    }
    static updateProduct(product) {
        let newProduct = ProductApi.updateProduct(product);
        //console.log("Dispatching Add Comment ...");
        Dispatcher.dispatch({
            actionType: ActionTypes.UPDATE_PRODUCT, // type
            product: newProduct  // payload
        });
    }
    static deleteProduct(id) {
        
        //console.log("Dispatching Delete Comment for id ..." + id);
            ProductApi.deleteProduct(id);
            Dispatcher.dispatch({
                actionType: ActionTypes.DELETE_PRODUCT,
                id: id
            });
    }
}
