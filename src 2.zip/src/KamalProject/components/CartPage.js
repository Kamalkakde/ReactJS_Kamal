import React from "react";
import {Form,FormControl} from 'react-bootstrap';
import ProductListCart from "./ProductListCart";
import {Button} from 'react-bootstrap';
import { Multiselect } from 'multiselect-react-dropdown';
// import $ from 'jquery';
import InitializeActions from "../actions/InitializeActions";
import ProductStore from '../stores/ProductStore';
import ProductActions from "../actions/ProductActions"


export default class CartPage extends React.Component {
    constructor(props) {
        super(props);
        this._onChange = this._onChange.bind(this);
        this.state = {
            product: ProductStore.getAllProducts(),
            deleteId : [],
            configState: [],
            options: [{name: 'Description', id: "1"},{name: 'Manufacturer', id: "2"},{name: 'Quantity', id: "3"}]
        };
        this.multiselectRef = React.createRef();
    }
    componentDidMount() {
        ProductStore.addChangeListener(this._onChange)
        InitializeActions.initProductsCart()
    }

    componentWillUnmount() {
        ProductStore.removeChangeListener(this._onChange)
    }

    _onChange() {
        this.setState({ product: ProductStore.getAllProducts() })
    }
   
    callbackFunctionForDeleteId = (deleteIdFromChild) => {
       this.setState({
      deleteId: [...this.state.deleteId, deleteIdFromChild]
    })
    
    }
    
    deleteProduct=(deleteArray)=>{
        if(deleteArray.length>0){
        if(window.confirm("Are you sure you want to proceed deleting?")){
                // your custom logic to page transition,like react-router-dom history.push()
                ProductActions.deleteProduct(deleteArray);
               // this.props.history.push('/');
                window.location.reload(true);
                 } else {
                  window.history.pushState(null, null, window.location.pathname);
                  this.isBackButtonClicked = false;
                }
            }else{
                alert("Please select a checkbox to delete a product")
            }
        }
         
    searchSpace=(event)=>{
        let keyword = event.target.value;
        this.setState({search:keyword});
        // console.log(keyword);
    }  
   

    onSelect=(selectedList, selectedItem)=> {
        // onChange={changeFunc}
        // var selectedValue = selectedItem.options[selectedItem.selectedIndex].value;
        
        if(!this.state.configState.includes(selectedItem.id))
            {
        this.setState({ 
            configState: this.state.configState.concat([selectedItem.id])
        });
         
    }
    }
   
    onRemove=(selectedList, removedItem)=> {
        // onChange={changeFunc}
        console.log(removedItem)
        
       
        var array = [...this.state.configState]; // make a separate copy of the array
  var index = array.indexOf(removedItem.id);
  if (index !== -1) {
    array.splice(index, 1);
    console.log("spliced array"+array);
    this.setState({configState: array});
  }
 }


    render() {
        const items = this.state.product.filter((data)=>{
            if(this.state.search == null)
                return data
            else if(data.productName.toLowerCase().includes(this.state.search.toLowerCase())){
            // else if(data.productName.toLowerCase().includes(this.state.search.toLowerCase()) || data.productDescription.toLowerCase().includes(this.state.search.toLowerCase()) || data.manufacturer.toLowerCase().includes(this.state.search.toLowerCase()) || data.quantity.toLowerCase().includes(this.state.search.toLowerCase()) || data.price.toLowerCase().includes(this.state.search.toLowerCase())){
                return data
            }
        })
        
            return (
                <>
                   {/* <div className = "addDeleteSearch">  */}
                   <div className = "formatOptions"> 
                   <div className = "buttons">
                    {/* <Button href="/addProduct" variant="primary">ADD</Button> */}
                    <Button variant="primary" onClick={()=>{localStorage.getItem('user')? this.deleteProduct(this.state.deleteId): this.props.history.push('/login');}}>Delete</Button>{' '}
                   </div>
                    <Form>
                    <Multiselect
                    options={this.state.options} // Options to display in the dropdown
                    selectedValues={this.state.selectedValue} // Preselected value to persist in dropdown
                    showCheckbox={true}
                    onSelect={this.onSelect} // Function will trigger on select event
                    onRemove={this.onRemove} // Function will trigger on remove event
                    displayValue="name" // Property name to display in the dropdown options
                    //ref={this.multiselectRef}
                    />
                    </Form>
                    <Form inline>
                    <FormControl type="text" placeholder="Search Product" onChange={(e)=>this.searchSpace(e)} />
                    </Form>
                   </div>
                    <ProductListCart filteredProducts={items} config= {this.state.configState} product= {items} parentCallBackDeleteId = {this.callbackFunctionForDeleteId} />
                </>
            );
    }
}
