import React from 'react';
 import {Link} from 'react-router-dom';
import { MDBCardTitle, MDBCardImage, MDBCardText, MDBCardBody, MDBCard, MDBInput } from 'mdbreact';
import {Button} from 'react-bootstrap';
import {EmpConsumer} from '../EmpContext';
import ProductApi from '../data/ProductApi';
import ProductActions from '../actions/ProductActions';


export default class Product extends React.Component {
  constructor(props){
  super(props)
  this.state={
          // counter : 0,
          // likes: 0
  };

}


  
    selectCheckBox = (id) =>{
    this.props.parentCallBackFromProductList(id);
    }
  render() {
    const path=`/${this.props.productName}`; 
    return (
    //     <tr>
    //       <td>{this.props.id}</td>
    // <td><Link to={path}>{this.props.productName} </Link></td>
    //       <td>{this.props.quantity}</td>
    //       <td>{this.props.children}</td>
    //     </tr>
    <>
    <MDBCard style={{ width: "15rem", margin: "10px" }}>
    <MDBCardBody>
      <div className = "checkandtitle">
    <MDBCardTitle>{this.props.productName}</MDBCardTitle>
    {/* <MDBInput type="checkbox" id="checkbox1" /> */}
    <MDBInput filled type='checkbox' id='checkbox1' containerClass='mr-5' onClick={() => {this.selectCheckBox(this.props.id)}}/>
    
    </div>
    <MDBCardImage className="img-fluid" src="https://mdbootstrap.com/img/Photos/Others/images/43.jpg" waves />
    {this.props.config.includes("1") &&
    (<MDBCardText>
    {this.props.productDescription}
    </MDBCardText>)
    }
    {this.props.config.includes("2") &&
    <MDBCardText>
    {this.props.manufacturer}
    </MDBCardText>
    }
    <MDBCardText>
    Rs. {this.props.price}
    </MDBCardText>
    {this.props.config.includes("3") &&
    <MDBCardText>
    {this.props.quantity}
    </MDBCardText>
  }
    
    <EmpConsumer>
        {(contextVal) => (
            <>
                {/* <label>Employee Name: */}
                    {/* <input type="text" onInput={(e) => contextVal.setEmpname(e.target.value)} defaultValue={contextVal.empname}/> */}
                    <Link to={path} params={this.props}>
                      <Button variant="primary" size="sm" 
                      onClick={(e) => {
                        contextVal.toggleManager(this.props);
                      }}
                      defaultValue={this.props}>More Details</Button><br></br>
                      </Link>
                      
                {/* </label> */}
            </>   
        )}
    </EmpConsumer>
    <Button variant="primary" size="sm"
                      onClick={(e) => {

                        ProductActions.addProductToCart(this.props);
                        // this.props.history.push('/');
                      }}
                      >Add to Cart</Button>
    </MDBCardBody>
    </MDBCard>
    
    </>
    );
  }
}