import React from 'react';
import { Formik } from 'formik';
import { Link } from 'react-router-dom';
import {Button} from 'react-bootstrap';
// import { withFormik, Form, Field } from 'formik'
// import * as Yup from 'yup'
//import AddProductPage from './AddProductPage';
import {MDBInput } from 'mdbreact';
import {Form} from 'react-bootstrap';

export default class EditProductForm extends React.Component {
    constructor(props) {
      super(props);
      console.log(this.props);
      this.onSubmit = this.onSubmit.bind(this);
    }
    
    onSubmit(values) {
      values.preventDefault();
      var product = {};
      product.id=this.refs.id.value;
      product.productID=this.refs.productID.value;
      product.productName = this.refs.productName.value;
      product.productDescription = this.refs.productDescription.value;
      product.manufacturer = this.refs.manufacturer.value;
      product.price =this.refs.price.value;
      product.quantity = this.refs.quantity.value;
      this.props.onSave(product);
    }

    render() {
        return (
          
          <Formik
          initialValues={{ id: `${this.props.prefilData.id}`, productName: `${this.props.prefilData.productName}`, productDescription: `${this.props.prefilData.productDescription}`, manufacturer: `${this.props.prefilData.manufacturer}`, price: `${this.props.prefilData.price}`, quantity: `${this.props.prefilData.quantity}` }}
          validate={values => {
            const errors = {};
            if (!values.productName) {
              errors.productName = 'Product Name is Required';
            }
            if (!values.productDescription) {
              errors.productDescription = 'Product Description is Required';
            }
            if (!values.manufacturer) {
              errors.manufacturer = 'Manufacturer is Required';
            }
            if (!values.price) {
              errors.price = 'Price is Required';
            }
            if (!values.quantity) {
              errors.quantity = 'Quantity is Required';
            }
            return errors;
          }}
          onSubmit={(values, { setSubmitting }) => {
            setTimeout(() => {
              //alert(JSON.stringify(values, null, 2));
              setSubmitting(false);
            }, 400);
            this.props.onSave(values);
          }}
        >
          {({
            values,
            errors,
            touched,
            handleChange,
            handleBlur,
            handleSubmit,
            isSubmitting,
            /* and other goodies */
          }) => (
      
    <div class="container">
		<div class="card">
			<div class="container-fliud">
					<div class="preview col-md-6">
            <Form>
            <h1>Update Product</h1>
            <form onSubmit={handleSubmit}>
              <MDBInput 
                placeholder="Enter Product Name"
                label="Product Name"
                size="lg"
                type="productName"
                name="productName"
                onChange={handleChange}
                onBlur={handleBlur}
                value={values.productName}
              />
              <div className="errorClass">
              {errors.productName && touched.productName && errors.productName}<br/>
              </div>
              <MDBInput 
                label="Product Description"
                size="lg"
                type="productDescription"
                name="productDescription"
                placeholder="Enter Product Description"
                onChange={handleChange}
                onBlur={handleBlur}
                value={values.productDescription}
              />
              <div className="errorClass">
              {errors.productDescription && touched.productDescription && errors.productDescription}<br/>
              </div>
              <MDBInput 
                label="Manufacturer"
                size="lg"
                type="manufacturer"
                name="manufacturer"
                placeholder="Enter Manufacturer"
                onChange={handleChange}
                onBlur={handleBlur}
                value={values.manufacturer}
              />
              <div className="errorClass">
              {errors.manufacturer && touched.manufacturer && errors.manufacturer}<br/>
              </div>
              <MDBInput 
                label="Price"
                size="lg"
                pattern='[0-9]*'
                type="price"
                name="price"
                placeholder="Enter Price"
                onChange={handleChange}
                onBlur={handleBlur}
                value={values.price}
              />
              <div className="errorClass">
              {errors.price && touched.price && errors.price}<br/>
              </div>
              <MDBInput 
                label="Quantity"
                size="lg"
                pattern='[0-9]*'
                type="quantity"
                name="quantity"
                placeholder="Enter Quantity"
                onChange={handleChange}
                onBlur={handleBlur}
                value={values.quantity}
              />
              <div className="errorClass">
              {errors.quantity && touched.quantity && errors.quantity}<br/>
              </div>
              <Button variant="primary" type="submit" disabled={isSubmitting}>UPDATE</Button>{' '}
              <Link to={`/${this.props.productName}`} params={this.props}>
              <Button variant="primary">BACK</Button>{' '}
              </Link>
            </form>
            </Form>
            </div>
				</div>
			</div>
      </div>
          )}
        </Formik>
        );
    }
  }