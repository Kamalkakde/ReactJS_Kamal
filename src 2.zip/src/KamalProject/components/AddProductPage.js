import React from 'react';
import { withRouter } from 'react-router-dom';
import ProductForm from './ProductForm';
import ProductActions from '../actions/ProductActions';


class AddProductPage extends React.Component {
    constructor(props) {
      super(props);
      this.saveProduct = this.saveProduct.bind(this);
      this.isBackButtonClicked = false; 
    }
    componentDidMount() {
        window.history.pushState(null, null, window.location.pathname);
        window.addEventListener('popstate', this.onBackButtonEvent);
      }

    onBackButtonEvent = (e) => {
        e.preventDefault();
        if (!this.isBackButtonClicked) {
    
      if (window.confirm("Can't save changes. Are you sure you want to proceed?")) {
           this.isBackButtonClicked = true;
           // your custom logic to page transition,like react-router-dom history.push()
           this.props.history.push('/')
            } else {
             window.history.pushState(null, null, window.location.pathname);
             this.isBackButtonClicked = false;
           }
        }
      }

    componentWillUnmount = () => {
        window.removeEventListener('popstate', this.onBackButtonEvent);
      }

    
    saveProduct(product) {
        ProductActions.addProduct(product);
        this.props.history.push('/');
        window.location.reload(true);
    }

    render() {
        return (
            <ProductForm onSave={this.saveProduct} />
        );
    }
}

export default withRouter(AddProductPage);
