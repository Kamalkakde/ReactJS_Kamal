import React from "react";
import {Button} from 'react-bootstrap';
import {EmpConsumer} from '../EmpContext';
import {Link} from 'react-router-dom';
import ProductActions from '../actions/ProductActions'
// import { MDBCardTitle, MDBCardImage, MDBCardText, MDBCardBody, MDBCard, MDBInput } from 'mdbreact';

export default class DetailsProductPage extends React.Component {  

  constructor(props)
  {
    super(props);
    this.state = {prefilData : {}}
  }

  componentDidMount()
  {
	// ProductActions.topViewdProduct( this.props.match.params.productName);
  }
    render() {
		
		 
		
		
        return (
            <>
                {/* <h3>Product Name:{this.props.match.params.productName}</h3>
                <h5>Product Name:{this.props.productQuantity}</h5>
                <h5>Product Name:{this.props.match.params.productName}</h5>
                <h5>Product Name:{this.props.match.params.productName}</h5>
                <h5>Product Name:{this.props.match.params.productName}</h5>
                <br/> */}
                {/* <Button href="/"variant="primary">back</Button>{' '}
                <Button href="/edit" variant="primary">edit</Button>{' '} */}
            <EmpConsumer>
                {(contextVal) => (
                    
                    <>
                        {/* <li>{contextVal.manager.id}</li> */}
                         {/* <h3>Product ID:{contextVal.manager.id}</h3>
                         <h3>Product Name:{contextVal.manager.productName}</h3>
                         <h3>Product Description:{contextVal.manager.productDescription}</h3>
                         <h5>Manufacturer:{contextVal.manager}</h5>
                         <h5>Price:{contextVal.manager}</h5> }
                         <h5>Product Quantity:{contextVal.manager.children}</h5> */}

<div className="container">
		<div className="card">
			<div className="container-fliud">
				<div className="wrapper row">
					<div className="preview col-md-6">
						
						<div className="preview-pic tab-content">
						  <div className="tab-pane active" id="pic-1"><img src="http://placekitten.com/400/252" alt="No_Internet" /></div>
						  <div className="tab-pane" id="pic-2"><img src="http://placekitten.com/400/252" alt="No_Internet" /></div>
						  <div className="tab-pane" id="pic-3"><img src="http://placekitten.com/400/252" alt="No_Internet" /></div>
						  <div className="tab-pane" id="pic-4"><img src="http://placekitten.com/400/252" alt="No_Internet" /></div>
						  <div className="tab-pane" id="pic-5"><img src="http://placekitten.com/400/252" alt="No_Internet" /></div>
						</div>
						<ul className="preview-thumbnail nav nav-tabs">
						  <li className="active"><a href="test" data-target="#pic-1" data-toggle="tab"><img src="http://placekitten.com/200/126" alt="No_Internet" /></a></li>
						  <li><a href="test" data-target="#pic-2" data-toggle="tab"><img src="http://placekitten.com/200/126" alt="No_Internet" /></a></li>
						  <li><a href="test" data-target="#pic-3" data-toggle="tab"><img src="http://placekitten.com/200/126" alt="No_Internet" /></a></li>
						  <li><a href="test" data-target="#pic-4" data-toggle="tab"><img src="http://placekitten.com/200/126" alt="No_Internet" /></a></li>
						  <li><a href="test" data-target="#pic-5" data-toggle="tab"><img src="http://placekitten.com/200/126" alt="No_Internet" /></a></li>
						</ul>
						
					</div>
					<div className="details col-md-6">
						<h3 className="product-title">{contextVal.manager.productName}</h3>
						<div className="rating">
							<div className="stars">
								<span className="fa fa-star checked"></span>
								<span className="fa fa-star checked"></span>
								<span className="fa fa-star checked"></span>
								<span className="fa fa-star"></span>
								<span className="fa fa-star"></span>
							</div>
							<span className="review-no">Qty : {contextVal.manager.quantity}</span>
						</div>
						<p className="product-description">{contextVal.manager.productDescription}</p>
						
						{/* <p class="vote"><strong>91%</strong> of buyers enjoyed this product! <strong>(87 votes)</strong></p> */}
						 <h5 className="sizes">Manufacturer:
							<span className="size" data-toggle="tooltip" title="small">{contextVal.manager.manufacturer}</span>
							{/* <span class="size" data-toggle="tooltip" title="medium">m</span>
							<span class="size" data-toggle="tooltip" title="large">l</span>
							<span class="size" data-toggle="tooltip" title="xtra large">xl</span> */}
						</h5>
            			<h4 className="price">current price:  <span>Rs.{contextVal.manager.price}</span></h4>
						{/*<h5 class="colors">colors:
							<span class="color orange not-available" data-toggle="tooltip" title="Not In store"></span>
							<span class="color green"></span>
							<span class="color blue"></span>
						</h5> */}
						<div className="action">
							{/* <button class="add-to-cart btn btn-default" href="/" type="button">back</button> */}
                            <Link to={`/${contextVal.manager.productName}/edit`} params={this.props}>
              <Button className="add-to-cart btn btn-default" variant="primary" >Edit</Button>
              {/* <button class="like btn btn-default" type="button"><span class="fa fa-heart"></span></button> */}
						</Link>
						<Button className="add-to-cart btn btn-default" href="/" variant="primary">back</Button>
              {/* <Button className="add-to-cart btn btn-default" href={`/${contextVal.manager.productName}/edit`} onClick={(e) => contextVal.toggleManager(contextVal.manager)} variant="primary">edit</Button> */}

            </div>
					</div>
				</div>
			</div>
		</div>
	</div>
                    </>   
                )}
            </EmpConsumer>
        </>
        );
    }
}