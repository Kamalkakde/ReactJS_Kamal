import React from 'react';
 import {Link} from 'react-router-dom';
import { MDBCardTitle, MDBCardImage, MDBCardText, MDBCardBody, MDBCard, MDBInput } from 'mdbreact';
import {Button} from 'react-bootstrap';
import {EmpConsumer} from '../EmpContext';
import ProductApi from '../data/ProductApi';
import ProductActions from '../actions/ProductActions';


export default class ProductCart extends React.Component {
  constructor(props){
  super(props)
  this.state={
          // counter : 0,
          // likes: 0
  };
  // this.incFav = this.incFav.bind(this);
}

    // incFav() {
    // this.setState(prevState => ({ likes: prevState.likes + 1 }));
    // }


    // deleteProduct=(deleteArray)=>{
    //   if(deleteArray.length>0){
    //   if(window.confirm("Are you sure you want to proceed deleting?")){
    //           // your custom logic to page transition,like react-router-dom history.push()
    //           ProductActions.deleteProduct(deleteArray);
    //          // this.props.history.push('/');
    //           window.location.reload(true);
    //            } else {
    //             window.history.pushState(null, null, window.location.pathname);
    //             this.isBackButtonClicked = false;
    //           }
    //       }else{
    //           alert("Please select a checkbox to delete a product")
    //       }
    //   }

      deleteProduct=(deleteArray)=>{
                ProductActions.deleteProduct(deleteArray);
               // this.props.history.push('/');
                window.location.reload(true);
                 } 
  
    selectCheckBox = (id) =>{
    this.props.parentCallBackFromProductList(id);
    }
  render() {
    const path=`/${this.props.productName}`; 
    return (
    //     <tr>
    //       <td>{this.props.id}</td>
    // <td><Link to={path}>{this.props.productName} </Link></td>
    //       <td>{this.props.quantity}</td>
    //       <td>{this.props.children}</td>
    //     </tr>
    <>
    <MDBCard style={{ width: "15rem", margin: "10px" }}>
    <MDBCardBody>
      <div className = "checkandtitle">
    <MDBCardTitle>{this.props.productName}</MDBCardTitle>
    {/* <MDBInput type="checkbox" id="checkbox1" /> */}
    <MDBInput filled type='checkbox' id='checkbox1' containerClass='mr-5' onClick={() => {this.selectCheckBox(this.props.id)}}/>
    
    </div>
    <MDBCardImage className="img-fluid" src="https://mdbootstrap.com/img/Photos/Others/images/43.jpg" waves />
    {this.props.config.includes("1") &&
    (<MDBCardText>
    {this.props.productDescription}
    </MDBCardText>)
    }
    {this.props.config.includes("2") &&
    <MDBCardText>
    {this.props.manufacturer}
    </MDBCardText>
    }
    <MDBCardText>
    Rs. {this.props.price}
    </MDBCardText>
    {this.props.config.includes("3") &&
    <MDBCardText>
    {this.props.quantity}
    </MDBCardText>
  }
     {/* <Link to={path} params={this.props}>
    <Button href="/path" variant="primary" size="sm">More Details</Button>
    </Link> */}
    {/* <EmpConsumer>
        {(contextVal) => ( */}
            <>
                {/* <label>Employee Name: */}
                    {/* <input type="text" onInput={(e) => contextVal.setEmpname(e.target.value)} defaultValue={contextVal.empname}/> */}
                    <Link to='cart' params={this.props}>
                      <Button variant="primary" size="sm" 
                      onClick={(e) => {
                        this.deleteProduct(this.props.id)
                      }}
                      defaultValue={this.props}>Delete</Button><br></br>
                      
                      </Link>
                      
                {/* </label> */}
            </>   
        {/* )}
    </EmpConsumer> */}
    
    </MDBCardBody>
    </MDBCard>
    
    </>
    );
  }
}