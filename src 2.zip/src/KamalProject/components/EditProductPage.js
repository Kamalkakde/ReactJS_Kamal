import React from 'react';
import { withRouter } from 'react-router-dom';
import EditProductForm from './EditProductForm';
import ProductActions from '../actions/ProductActions';
import {EmpConsumer} from '../EmpContext';

class EditProductPage extends React.Component {
    constructor(props) {
      super(props);
      this.updateProduct = this.updateProduct.bind(this);
    }
    componentDidMount() {
        window.history.pushState(null, null, window.location.pathname);
        window.addEventListener('popstate', this.onBackButtonEvent);
      }

    onBackButtonEvent = (e) => {
        console.log(e);
        e.preventDefault();
        if (!this.isBackButtonClicked) {
    
      if (window.confirm("Can't save changes. Are you sure you want to proceed?")) {
           this.isBackButtonClicked = true;
           // your custom logic to page transition,like react-router-dom history.push()
           this.props.history.push('/')
            } else {
             window.history.pushState(null, null, window.location.pathname);
             this.isBackButtonClicked = false;
           }
        }
      }

    componentWillUnmount = () => {
        window.removeEventListener('popstate', this.onBackButtonEvent);
        
      }

    updateProduct(product) {
        // const path=`/${this.props.productName}`; 
        ProductActions.updateProduct(product);
        this.props.history.push('/');
        // alert(this.contextVal.productName);
        // alert(path);
        this.isBackButtonClicked = false; 
        // window.location.reload(true);
        window.location.reload()
    }

    render() {
        return (
            <EmpConsumer>
                { (contextVal) => (
            <EditProductForm prefilData={contextVal.manager} onSave={this.updateProduct} />
                )}
            </EmpConsumer>
        );
    }
}

export default withRouter(EditProductPage);
