import React from 'react';
import { Formik } from 'formik';
import {Button} from 'react-bootstrap';
import {MDBInput } from 'mdbreact';
import {Form} from 'react-bootstrap';

export default class ProductForm extends React.Component {
    constructor(props) {
      super(props);
      this.onSubmit = this.onSubmit.bind(this);
      // this.state={counter:0};
    }

    
    onSubmit(values) {
      values.preventDefault();
      var product = {};
      product.productName = this.refs.productname.value;
      product.quantity = this.refs.productDescription.value;
      product.quantity = this.refs.manufacturer.value;
      product.price =this.refs.price.value;
      product.quantity = this.refs.quantity.value;
      product.counter = this.refs.counter.value;
      this.props.onSave(product);
    }

    render() {
        return (
          <Formik
          initialValues={{ productName: '', productDescription: '', manufacturer: '', price: '', quantity: '', counter:0}}
          validate={values => {
            const errors = {};
            if (!values.productName) {
              errors.productName = 'Product Name is Required';
            }
            if (!values.productDescription) {
              errors.productDescription = 'Product Description is Required';
            }
            if (!values.manufacturer) {
              errors.manufacturer = 'Manufacturer is Required';
            }
            if (!values.price) {
              errors.price = 'Price is Required';
            }
            if (!values.quantity) {
              errors.quantity = 'Quantity is Required';
            }
            return errors;
          }}
          onSubmit={(values, { setSubmitting }) => {
            setTimeout(() => {
              //alert(JSON.stringify(values, null, 2));
              setSubmitting(false);
            }, 400);
            this.props.onSave(values);
          }}
        >
          {({
            values,
            errors,
            touched,
            handleChange,
            handleBlur,
            handleSubmit,
            isSubmitting,
            /* and other goodies */
          }) => (
    <div class="container">
		<div class="card">
			<div class="container-fliud">
				{/* <div class="wrapper row"> */}
					<div class="preview col-md-6">
            <Form>
            <h3>Add Product</h3>
            <form onSubmit={handleSubmit}>
              {/* <input
                type="productName"
                name="productName"
                placeholder="Enter Product Name"
                onChange={handleChange}
                onBlur={handleBlur}
                value={values.productName}
              /> */}
              <MDBInput 
              label="Product Name" 
              size="lg"
              type="productName"
              name="productName"
              placeholder="Enter Product Name"
              onChange={handleChange}
              onBlur={handleBlur}
              value={values.productName} 
               />
              <div className="errorClass">
              {errors.productName && touched.productName && errors.productName}<br/>
              </div> 
              {/* <input
                type="productDescription"
                name="productDescription"
                placeholder="Enter Product Description"
                onChange={handleChange}
                onBlur={handleBlur}
                value={values.productDescription}
              /> */}
               <MDBInput 
              type="productDescription" 
              label="Product Description"
              name="productDescription"
              placeholder="Enter Product Description"
              size="lg"
              onChange={handleChange}
              onBlur={handleBlur}
              value={values.productDescription}
                   />
              <div className="errorClass">
              {errors.productDescription && touched.productDescription && errors.productDescription}<br/>
              </div>
              <MDBInput 
                type="manufacturer"
                name="manufacturer"
                label="Manufacturer"
                size="lg"
                placeholder="Enter Manufacturer"
                onChange={handleChange}
                onBlur={handleBlur}
                value={values.manufacturer}
              />
              <div className="errorClass">
              {errors.manufacturer && touched.manufacturer && errors.manufacturer}<br/>
              </div>
              <MDBInput 
                type="price"
                name="price"
                pattern='[0-9]*'
                placeholder="Enter Price"
                label="Price"
                size="lg"
                onChange={handleChange}
                onBlur={handleBlur}
                value={values.price}
              />
              <div className="errorClass">
              {errors.price && touched.price && errors.price}<br/>
              </div>
              <MDBInput 
                type="quantity"
                name="quantity"
                pattern='[0-9]*'
                placeholder="Enter Quantity"
                label="Quantity "
                size="lg"
                onChange={handleChange}
                onBlur={handleBlur}
                value={values.quantity}
              />
              <div className="errorClass">
              {errors.quantity && touched.quantity && errors.quantity}<br/>
              </div>
              <Button variant="primary" type="submit" disabled={isSubmitting}>SUBMIT</Button>{' '}
              <Button className="add-to-cart btn btn-default" href="/" variant="primary">BACK</Button>
            </form>
            </Form>
            </div>
				</div>
			</div>
		{/* </div> */}
	</div>
          )}
        </Formik>
        );
    }
  }