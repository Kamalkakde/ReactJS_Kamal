import React from 'react';
import '../Products.css';
import ProductCart from './ProductCart';

import {MDBRow } from 'mdbreact';

export default class ProductListCart extends React.Component {
 

  render () {
    //console.log("CommentList render => comments = " + this.props.product);
    // console.log(this.props.config);
    let productsJson = this.props.product.map(product => (
      <ProductCart  key={product.id} 
                id={product.id} 
                productName={product.productName} 
                productDescription={product.productDescription} 
                manufacturer={product.manufacturer} 
                price={product.price} 
                quantity={product.quantity}
                counter={product.counter}
                parentCallBackFromProductList = {this.props.parentCallBackDeleteId} 
                config= {this.props.config}>
          
        </ProductCart>
      ));
   
    return (
      // <>
      //   <table>
      //     <thead>
      //       <tr>
      //         {/* <th>ID</th> */}
      //         <th>Product Name</th>
      //         <th>Quantity</th>
      //         <th>Price</th>
      //       </tr>
      //     </thead>
      //     <tbody>
      //       {productsJson}
      //     </tbody>
      //   </table>
      // </>


      
    <MDBRow>
        {productsJson}
    </MDBRow>
    );
  }
}
