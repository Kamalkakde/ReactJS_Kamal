import React from 'react';

export const EmpContext = React.createContext();

export class EmpProvider extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            empname: "google",  
            manager: {} ,
            idArray : {},    
        }
    }

    render() {
        return (
            <EmpContext.Provider value={{
                ...this.state,
                setEmpname: (name) => this.setState({empname: name}),
                toggleManager: (product) => this.setState({manager: product}),
                setIdArray : (idJson) => this.setState({idArray: idJson}),
            }}>
                {this.props.children}
            </EmpContext.Provider>
        )
    }
}

export const EmpConsumer = EmpContext.Consumer;

