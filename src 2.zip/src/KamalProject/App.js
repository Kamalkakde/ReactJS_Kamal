import React, { Suspense} from 'react';
import { BrowserRouter as Router, Route, Switch} from 'react-router-dom';
import AllProductsPage from './components/AllProductsPage';
import AddProductPage from './components/AddProductPage';
import DetailsProductPage from './components/DetailsProductPage';
import CartPage from './components/CartPage';
import EditProductPage from './components/EditProductPage';
// import {Navbar, NavDropdown, Nav, Form, Button, FormControl} from 'react-bootstrap';
import {Navbar, NavDropdown, Nav} from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
// import MyProfilePage from './components/MyProfilePage';
import {EmpProvider} from './EmpContext'


class LinkCreated extends React.Component {
  constructor(props){
    super(props);

    this.state={
      search:null
    };
  }

  searchSpace=(event)=>{
    let keyword = event.target.value;
    this.setState({search:keyword})
    // console.log(keyword);
  }  
    render() {
    
    return (
      // <nav class="navBar">
      //   <NavLink class="navBar" activeClassName="current" to="/about">About</NavLink>
      //   <NavLink class="navBar" exact activeClassName="current" to="/">Products</NavLink>
      //   <NavLink class="navBar" activeClassName="current" to="/">Login</NavLink>
      // </nav>
        <Navbar bg="light" expand="lg">
        <Navbar.Brand href="/"><b>Klipkart</b></Navbar.Brand>
        <Navbar.Toggle aria-controls="basic-navbar-nav" />
        <Navbar.Collapse id="basic-navbar-nav">
          <Nav className="mr-auto">
            {/* <Nav.Link href="/about"><b>About</b></Nav.Link> */}
            <Nav.Link href="/"><b>Products</b></Nav.Link>
            {/* <Nav.Link href="/chart"><b>Top Viewed Product</b></Nav.Link> */}
            <Nav.Link href="/cart"><b>Cart</b></Nav.Link>

          </Nav>
          {/* <Form inline>
            <FormControl type="text" placeholder="Search" className="mr-sm-2" onChange={(e)=>this.searchSpace(e)} />  
            <Button variant="outline-success"><b>Search</b></Button>
          </Form> */}
        </Navbar.Collapse>
      </Navbar>
    );
  }
}
export default class App extends React.Component {
  render() {
      return (
        <Router class="navBar">
          
            <LinkCreated/>
            <Switch>
              <Route exact path="/cart" component={CartPage}/>
              {/* <Route exact path="/about" component={AboutPage}/> */}
              <Route path="/addProduct" component={AddProductPage}/>
              <EmpProvider>
              <Route exact path="/" component={AllProductsPage} history ={this.props.history}/>
              <Route exact path="/:productName/edit" component={EditProductPage} history ={this.props.history}/>
              <Route exact path="/:productName" component={DetailsProductPage} history ={this.props.history}/>
              
              </EmpProvider>
              {/* <Route exact path="/:productName" component={DetailsProductPage} history ={this.props.history}/> */}
              
            </Switch>
        </Router>
      );
  }
}