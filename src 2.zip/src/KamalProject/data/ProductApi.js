// import _ from 'lodash';
import v4 from 'uuid/v4';

//var qs = require('qs');
const axios = require('axios');
//let currentID = 3;
const uuid = require('uuid').v4;
const _clone = function(item) {
	return JSON.parse(JSON.stringify(item)); //return cloned copy so that the item is passed by value instead of by reference
};

export default class ProductApi {

	static getAllProducts(cb) {
        axios.get('http://localhost:3000/ProductsJsonData')
        .then(response => cb(response.data))
		.catch(error => { throw error })
    }
	// static getAllComments() {
	// 	return _clone(CommentData.comments);
	// }
	static getAllProductsCart(cb) {
        axios.get('http://localhost:3000/ProductsJsonDataCart')
        .then(response => cb(response.data))
		.catch(error => { throw error })
    }
	

	static saveProduct(product) {
		//currentID = currentID + 1;
	product.productID = uuid();
	//product.productID = product.id;
	//const axios = require('axios');
    
	axios.post('http://localhost:3000/ProductsJsonData',product).then(resp => {
    console.log(resp.data);
	}).catch(error => {
    console.log(error);
	}); 
	return _clone(product);
	}

	static saveProductToCart(product) {
		//currentID = currentID + 1;
	// product.productID = uuid();
	//product.productID = product.id;
	//const axios = require('axios');
    
	axios.post('http://localhost:3000/ProductsJsonDataCart',product).then(resp => {
    console.log(resp.data);
	}).catch(error => {
    console.log(error);
	}); 
	return _clone(product);
	}


	static deleteProduct(id, cb) {
		//alert(id);
		axios.delete(`http://localhost:3000/ProductsJsonDataCart/${id}`)
		.then(response => {cb(response.data);})
		.catch(error => { throw error })
		
		return _clone(id);
	}

	// static deleteProduct(idArray) {
	// 	//currentID = currentID + 1;
	// 	//idArray.productID = uuid();
	// //product.productID = product.id;
	// const axios = require('axios');
	
	// // var idString = idArray.join(',');
	// // console.log(idString);
	// // alert(idString);
	// 	//var url=`http://localhost:3333/ProductsJsonData/?id=${idString}`;
	// 	//alert(url);
	// 	axios.delete(`http://localhost:3333/ProductsJsonData/`,{data:idArray}).then(resp => {
	// 		//for(var i=0;i<idArray.length;i++){
	// 	// axios.delete(`http://localhost:3333/ProductsJsonData/${idArray[i]}`).then(resp => {
    // 	console.log(resp.data);
	// 	}).catch(error => {
    // 	console.log(error);
	// 	}); 
	// 	//console.log("Deleted:"+ idArray[i]);
	
	// 	//}
	// return _clone(idArray);
	
	// }

	static updateProduct(product) {
		//currentID = currentID + 1;
	//product.productID = uuid();
	//product.productID = product.id;
//	const axios = require('axios');
    // alert(JSON.stringify(product));
	axios.put(`http://localhost:3000/ProductsJsonData/${product.id}/`,product).then(resp => {
	console.log(resp.data);

	}).catch(error => {
    console.log(error);
	}); 
	return _clone(product);
	}
	

static deleteProducts(idArray, cb) {
	alert(JSON.stringify(idArray));
	idArray.forEach(id => this.deleteProduct(id, ()=>{}))
}

	// static deleteComment(id) {
	// 	_.remove(ProductData.comments, { id: id});
	// }
}